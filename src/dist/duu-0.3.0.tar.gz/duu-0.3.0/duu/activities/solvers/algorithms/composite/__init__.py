import abc

from duu.activities.solvers.algorithms import CompositeAlgorithm
from duu.activities.solvers.algorithms.composite.ns_global import \
    NestedSamplingWithGlobalSearch
